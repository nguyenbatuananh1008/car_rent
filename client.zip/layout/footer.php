<?php

?>
<!DOCTYPE html>
<section id="footer" class="pt-3 pb-3">
<div class="container-xl">
  <div class="row footer_1">
    <div class="col-md-4">
	 <div class="footer_1i">
	  <h4><a href="index.html"><i class="fa fa-car col_oran "></i> CAR  <span class="fw-normal"></span>Lease</a></h4>
	  <p class="mt-3">Use securing confined his shutters. Delightful as he it acceptance an solicitude discretion.</p>
	  <h6 class="mt-3 fw-normal"><i class="fa fa-map col_oran me-1"></i> 36 Nora Dreek,  Old East 2360, India</h6>
	  <h6 class="mt-3 fw-normal"><a href="#"><i class="fa fa-phone col_oran me-1"></i> (123) 456-7890</a></h6>
	  <h6 class="mt-3 mb-0 fw-normal"><a href="#"><i class="fa fa-envelope col_oran me-1"></i> info@gmail.com</a></h6>
	 </div>
	</div>
	<div class="col-md-2">
	 <div class="footer_1i">
	  <h4>COMPANY</h4>
	  <div class="row">
	  <h6 class="fw-normal mt-2 col-md-12 col-6"><a href="#">New York</a></h6>
	  <h6 class="fw-normal mt-2 col-md-12 col-6"><a href="#">Careers</a></h6>
	  <h6 class="fw-normal mt-2 col-md-12 col-6"><a href="#">Mobile</a></h6>
	  <h6 class="fw-normal mt-2 col-md-12 col-6"><a href="#">Blog</a></h6>
	  <h6 class="fw-normal mt-2 col-md-12 col-6"><a href="#">About Us</a></h6>
	  <h6 class="fw-normal mt-2 mb-0 col-md-12 col-6"><a href="#">How we work</a></h6>
	  </div>
	 </div>
	</div>
	<div class="col-md-3">
	 <div class="footer_1i">
	  <h4>WORK HOURS</h4>
      <p class="mt-3">Mon - Fri: <span class="fw-bold text-black">09:00AM - 09:00PM</span></p>
	  <p class="mt-3">Sat: <span class="fw-bold text-black">09:00AM - 06:00PM</span></p>
	  <p class="mt-3 mb-0">Sun: <span class="fw-bold text-black">Closed</span></p>
	 </div>
	</div>
	<div class="col-md-3">
	 <div class="footer_1i">
	  <h4>SUBSCRIPTION</h4>
      <p class="mt-3">Subscribe your Email address for latest news & updates.</p>
	  <input class="form-control" placeholder="Enter Email Address" type="text">
	  <h6 class="mb-0 mt-4"><a class="button pt-3 pb-3" href="#">Submit <i class="fa fa-check-circle ms-1"></i> </a></h6>
	 </div>
	</div>
  </div><hr>
  <div class="row footer_2">
   <div class="col-md-8">
    <div class="footer_2l">
	 <p class="mb-0 mt-1">© 2013 Your Website Name. All Rights Reserved | Design by <a class="col_green" href="http://www.templateonweb.com">TemplateOnWeb</a></p>
	</div>
   </div>
   <div class="col-md-4">
    <div class="footer_2r text-end">
	  <ul class="social-network social-circle mb-0">
					<li><a href="#" class="icoRss" title="Rss"><i class="fa fa-rss"></i></a></li>
					<li><a href="#" class="icoFacebook" title="Facebook"><i class="fa fa-pinterest"></i></a></li>
					<li><a href="#" class="icoTwitter" title="Twitter"><i class="fa fa-twitter"></i></a></li>
					<li><a href="#" class="icoLinkedin" title="Linkedin"><i class="fa fa-linkedin"></i></a></li>
				</ul>
	</div>
   </div>
  </div>
</div>
</section>